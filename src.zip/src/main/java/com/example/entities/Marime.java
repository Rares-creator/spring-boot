package com.example.entities;

public enum Marime {
  S,
  M,
  L,
  XL,
  XXL
}
