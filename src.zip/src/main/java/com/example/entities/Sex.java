package com.example.entities;

public enum Sex {
  MASCULIN,
  FEMININ
}
